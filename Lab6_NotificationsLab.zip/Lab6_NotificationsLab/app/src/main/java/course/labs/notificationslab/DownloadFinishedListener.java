package course.labs.notificationslab;

interface DownloadFinishedListener {
	void notifyDataRefreshed(String[] feeds);
}
